// src/app/features/tickets/services/tickets.service.ts - REEMPLAZAR COMPLETO

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, catchError, map, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Ticket, TicketFilters, TicketPriority, TicketType } from '../models/ticket.model';

export interface TicketConsorcioOption {
  id: number;
  nombre: string;
}

export interface TicketUnidadOption {
  id: number;
  consorcioId: number;
  nombre: string;
  piso: string;
  codigo: string;
}

export interface TicketProveedorOption {
  id: number;
  razonSocial: string;
  rubro?: string;
  activo: boolean;
}

interface TicketListResponse {
  data: Ticket[];
  total: number;
}

@Injectable({ providedIn: 'root' })
export class TicketsService {
  private readonly apiUrl = `${environment.apiUrl}/tickets`;
  private readonly consorciosUrl = `${environment.apiUrl}/consorcios`;
  private readonly unidadesUrl = `${environment.apiUrl}/unidades`;
  private readonly proveedoresUrl = `${environment.apiUrl}/proveedores`;

  constructor(private http: HttpClient) {}

  // ====================================
  // GET TICKETS
  // ====================================
  getTickets(filters: TicketFilters = {}): Observable<Ticket[]> {
    let params = new HttpParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== '') {
        const paramKey = this.mapFilterKey(key as keyof TicketFilters);
        params = params.set(paramKey, String(value));
      }
    });

    return this.http.get<TicketListResponse>(this.apiUrl, { params }).pipe(
      map(response => response.data || []),
      catchError(error => {
        console.error('Error al obtener tickets:', error);
        return throwError(() => error);
      })
    );
  }

  getTicketById(id: number): Observable<Ticket> {
    return this.http.get<Ticket>(`${this.apiUrl}/${id}`);
  }

  // ====================================
  // CREATE TICKET
  // ====================================
  createTicket(payload: {
    consorcio_id: number;
    unidad_id?: number | null;
    tipo: TicketType;
    prioridad: TicketPriority;
    titulo: string;
    descripcion: string;
    creado_por: number;
  }): Observable<Ticket> {
    return this.http.post<Ticket>(this.apiUrl, payload);
  }

  // ====================================
  // UPDATE ESTADO
  // ====================================
  updateTicketEstado(ticketId: number, estado: string): Observable<Ticket> {
    return this.http.patch<Ticket>(`${this.apiUrl}/${ticketId}/estado`, { estado });
  }

  // ====================================
  // UPDATE ASIGNACION
  // ====================================
  updateTicketAsignacion(ticketId: number, payload: {
    asignadoANombre?: string | null;
    asignadoRol?: string | null;
    proveedorId?: number | null;
  }): Observable<Ticket> {
    return this.http.patch<Ticket>(`${this.apiUrl}/${ticketId}/asignacion`, payload);
  }

  // ====================================
  // UPDATE COSTOS
  // ====================================
  updateTicketCostos(ticketId: number, payload: {
    estimacionCosto?: number | null;
    costoFinal?: number | null;
  }): Observable<Ticket> {
    return this.http.patch<Ticket>(`${this.apiUrl}/${ticketId}/costos`, payload);
  }

  // ====================================
  // COMENTARIOS
  // ====================================
  addComentario(payload: {
    ticketId: number;
    authorId: number;
    message: string;
    isInternal: boolean;
  }): Observable<any> {
    return this.http.post(`${this.apiUrl}/${payload.ticketId}/comentarios`, payload);
  }

  getComentarios(ticketId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/${ticketId}/comentarios`);
  }

  // ====================================
  // HISTORIAL
  // ====================================
  getTicketHistorial(ticketId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/${ticketId}/historial`);
  }

  // ====================================
  // ADJUNTOS
  // ====================================
  uploadAdjunto(ticketId: number, file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post(`${this.apiUrl}/${ticketId}/adjuntos`, formData);
  }

  getAdjuntos(ticketId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/${ticketId}/adjuntos`);
  }

  // ====================================
  // OPCIONES
  // ====================================
  getConsorcios(): Observable<TicketConsorcioOption[]> {
    return this.http.get<any[]>(this.consorciosUrl).pipe(
      map(res => res.map((c: any) => ({ id: c.id, nombre: c.nombre })))
    );
  }

  getUnidades(): Observable<TicketUnidadOption[]> {
    return this.http.get<any[]>(this.unidadesUrl).pipe(
      map(res => res.map((u: any) => ({
        id: u.id,
        consorcioId: u.consorcio_id,
        nombre: `${u.piso}-${u.codigo}`,
        piso: u.piso,
        codigo: u.codigo
      })))
    );
  }

  getProveedores(): Observable<TicketProveedorOption[]> {
    return this.http.get<any>(this.proveedoresUrl).pipe(
      map(res => {
        const data = Array.isArray(res) ? res : res?.data ?? [];
        return data.map((p: any) => ({
          id: p.id,
          razonSocial: p.razon_social,
          rubro: p.rubro,
          activo: p.activo
        }));
      })
    );
  }

  getPrioridades(): TicketPriority[] {
    return ['baja', 'media', 'alta', 'critica'];
  }

  getTipos(): TicketType[] {
    return ['mantenimiento', 'reclamo', 'limpieza', 'administrativo', 'mejora', 'otro'];
  }

  // ====================================
  // HELPERS
  // ====================================
  private mapFilterKey(key: keyof TicketFilters): string {
    const map: Record<string, string> = {
      consorcioId: 'consorcio_id',
      unidadId: 'unidad_id',
      asignadoRol: 'asignado_rol',
      proveedorId: 'proveedor_id',
      searchTerm: 'search'
    };
    return map[key] || key;
  }
}