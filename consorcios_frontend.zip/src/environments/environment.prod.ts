export const environment = {
  production: true,
  apiUrl: 'https://apiconsorcios.huelemu.com.ar',
  googleClientId: '214922698115-lsq51vuo1k32l9nknl96nu6bccrlfb48.apps.googleusercontent.com'
};