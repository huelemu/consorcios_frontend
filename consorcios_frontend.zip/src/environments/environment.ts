export const environment = {
  production: false,
  apiUrl: 'http://localhost:7000',
  googleClientId: '214922698115-lsq51vuo1k32l9nknl96nu6bccrlfb48.apps.googleusercontent.com'
};